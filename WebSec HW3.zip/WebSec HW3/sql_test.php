
<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "employees";// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$empNum = $_POST['number'];

$sql = "SELECT salary FROM salaries WHERE emp_no = ". $empNum;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo  $row["salary"]. "<br>";
    }
} else {
    echo "0 results";
}


$conn->close();
?>

</body>
</html>


