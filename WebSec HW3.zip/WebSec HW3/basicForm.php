<htmlS>
<head>
<title> A BASIC HTML FORM </title>
</head>
<body>

<FORM NAME = "form1" METHOD="POST" ACTION="sql_test.php">
	<INPUT TYPE ="TEXT" VALUE="number" NAME="number">
	<INPUT TYPE ="Submit" Name = "Submit1" Value = "Submit">
</FORM>

</body>
</html>
